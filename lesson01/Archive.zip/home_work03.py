n = int(input("Введите число n: "))
n1 = str(n)
n2 = n1 + n1
n3 = n1 + n1 + n1
result = n + int(n2) + int(n3)
print(result)
